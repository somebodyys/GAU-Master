import taskOne
import taskThree
import taskTwo

if __name__ == '__main__':
    # taskOne.run()
    # taskTwo.run()
    taskThree.run()
